# Handoff: vQuasar Console redesign (+ brand identity)

## Overview

A complete redesign of the **vQuasar** web console — the UI for a distributed
virtualization control plane built natively on Cloud Hypervisor. It replaces the
MVP console at `ui/` in `github.com/vquasar/vquasar` (React 18 + MUI + MUI
X-DataGrid + react-router + TanStack Query + Vite).

The redesign covers 14 screens, a dual dark/light theme on a single token set,
and the new brand identity (mark, wordmark, palette, typography).

Scope of the change vs. the MVP:

- Grouped sidebar with live counts, replacing the flat 10-item MUI `Drawer` list.
- Agent-connection + reconcile status pinned to the sidebar footer.
- Migration promoted to a first-class concept. **Ion Cyan is reserved strictly
  for in-flight state**; a pulsing dot means data is moving right now.
- Tasks carry their failure message inline in the table instead of in a
  dismissible `<Alert>`.
- Drift (desired ≠ observed) surfaced on Overview as its own metric.
- Dense, unified table treatment replacing MUI X-DataGrid's default chrome.
- A real light theme, equal in status to dark.

## About the design files

The two files in this bundle are **design references created in HTML** —
prototypes showing intended look and behavior. They are *not* production code to
copy.

They are authored in a streaming component format (`.dc.html`) that is specific
to the design tool. **Do not try to port that format.** Open them in a browser to
see the design, read them for exact values, then **recreate the design inside
`ui/`** using its existing environment: React + TypeScript, react-router,
TanStack Query hooks in `ui/src/api/hooks.ts`, and the types in
`ui/src/api/types.ts`.

Two structural notes about the prototypes that do NOT belong in production:

1. Screen switching is in-file component state (`state.screen`). In production
   these are **routes** — keep the MVP's route table in `ui/src/App.tsx` and
   extend it (see the route map below).
2. All styling is inline `style="…"` attributes, because the prototype format
   requires it. In production, use CSS custom properties + whatever styling
   approach `ui/` settles on (see "Implementation approach").
3. All data is hardcoded sample data. Wire every screen to the existing hooks.

## Fidelity

**High fidelity.** Colors, typography, spacing, borders, radii and states are
final. Recreate pixel-perfectly. Where a value here conflicts with an MUI
default, this document wins.

Two things are deliberately *not* final and need design follow-up before you
build them:

- **The functional icon family** (hosts, VMs, networks, volumes, images,
  migration, security groups, tasks, events). The redesigned sidebar is
  text-only. Do not reinstate the MVP's `@mui/icons-material` set — it clashes
  with the new identity. Ship text-only nav until icons arrive.
- **Console/serial screen and login page** are not designed yet. Leave the MVP's
  `Console.tsx` and `Login.tsx` functional and restyle them only as far as the
  token set takes them.

---

## Implementation approach

### Theming — do this first

The entire design runs on **one CSS custom-property set** with a
`[data-theme="light"]` override. Both themes must resolve from the same token
names; no component may hardcode a hex value.

Put the token block in a single global stylesheet, set `data-theme` on
`<html>`, and persist the choice (`localStorage`). Then either:

- **Recommended:** keep MUI for behavior-heavy primitives (menus, dialogs,
  popovers, focus management) but drive its `createTheme` palette from the same
  CSS variables, and build tables/cards/chips/badges as plain styled elements.
  The design's tables are simple CSS grids — MUI X-DataGrid's chrome fights
  this design and its density is wrong; replacing it is less work than
  overriding it.
- Or drop MUI entirely for these screens. The design uses no MUI-specific
  behavior except menus and dialogs.

`ui/src/theme.ts` currently hardcodes `mode: "dark"`, `primary #4f9cf9`,
`background.default #0e1116`, `paper #161b22`, `fontSize 13`. Quasar Blue is
unchanged (`#4F9CF9`); the backgrounds shift slightly (`#0B0F16` / `#161B22`).

### Fonts

```
Inter Tight  400 500 600 700   — brand, UI, all headings, table cells, buttons
Inter        400 500 600       — descriptive body copy and helper text only
JetBrains Mono 400 500         — identifiers, IPs, sizes, timestamps, task IDs,
                                 state chips, column headers
```

Load from Google Fonts (or self-host):
`Inter+Tight:wght@400;500;600;700&family=Inter:wght@400;500;600&family=JetBrains+Mono:wght@400;500`

The rule that keeps the console coherent: **anything machine-generated is
monospace** (IDs, addresses, byte sizes, versions, timestamps, state names,
column headers). Anything human-written is Inter Tight, or Inter when it is a
sentence of explanation.

---

## Design tokens

### Dark (default, `:root`)

```css
--bg:#0B0F16;        --surface:#161B22;   --surface-2:#12171F;
--surface-3:#1A212B; --inset:#0D1219;     --btn:#1D2530;  --btn-hover:#242E3B;
--line:#222A35;      --line-2:#2C3644;    --line-3:#3A4655;
--text:#F4F7FB;      --text-2:#A6B0BF;    --text-3:#6E7887; --text-4:#4E5867;
--blue:#4F9CF9;      --blue-2:#7CB6FB;
--blue-soft:rgba(79,156,249,.15);   --blue-line:rgba(79,156,249,.38);
--cyan:#58D6F5;
--cyan-soft:rgba(88,214,245,.14);   --cyan-line:rgba(88,214,245,.38);
--amber:#F5A94A;
--amber-soft:rgba(245,169,74,.14);  --amber-line:rgba(245,169,74,.36);
--red:#F2695F;
--red-soft:rgba(242,105,95,.14);    --red-line:rgba(242,105,95,.36);
--green:#4FD08A;
--green-soft:rgba(79,208,138,.13);  --green-line:rgba(79,208,138,.34);
--shadow:0 12px 32px rgba(0,0,0,.45);
```

### Light (`[data-theme="light"]`)

```css
--bg:#F1F4F9;        --surface:#FFFFFF;   --surface-2:#F7F9FC;
--surface-3:#EEF2F8; --inset:#F4F7FB;     --btn:#FFFFFF;  --btn-hover:#F1F4F9;
--line:#DFE5EE;      --line-2:#CBD4E1;    --line-3:#AEBACA;
--text:#0B0F16;      --text-2:#4A5666;    --text-3:#75828F; --text-4:#98A3B2;
--blue:#1E6FD9;      --blue-2:#1558B4;
--blue-soft:rgba(30,111,217,.09);   --blue-line:rgba(30,111,217,.28);
--cyan:#0A7E9E;
--cyan-soft:rgba(10,126,158,.09);   --cyan-line:rgba(10,126,158,.28);
--amber:#A66200;
--amber-soft:rgba(166,98,0,.09);    --amber-line:rgba(166,98,0,.26);
--red:#C0362C;
--red-soft:rgba(192,54,44,.08);     --red-line:rgba(192,54,44,.24);
--green:#0E7A50;
--green-soft:rgba(14,122,80,.08);   --green-line:rgba(14,122,80,.24);
--shadow:0 10px 28px rgba(15,26,44,.10);
```

Light-theme accents are darkened for AA contrast on white; do not reuse the dark
hexes on light surfaces.

### Semantic colour rules (enforce these in review)

| Colour | Meaning | Where |
| --- | --- | --- |
| Blue | primary action, selection, links, allocated capacity | buttons, active nav, resource names |
| Cyan | **live / in-flight only** | migrating, arriving, importing, snapshotting, streaming, connected agents |
| Green | healthy steady state | Running, Ready, Succeeded, ingress rules |
| Amber | needs attention, transitional, drift | Maintenance, Cordoned, Pending, override-differs |
| Red | failure | Failed, NotReady, errors, destructive actions |
| text-3 / surface-3 | inert | Stopped, Disabled, Cancelled, unattached |

Cyan must never be used decoratively. A cyan pulsing dot is a promise that bytes
are moving.

### Type scale

| Use | Family | Size | Weight | Tracking |
| --- | --- | --- | --- | --- |
| Page title | Inter Tight | 21px | 600 | -0.02em |
| Card / section title | Inter Tight | 13.5px | 600 | — |
| Metric number | Inter Tight | 25–27px | 600 | -0.03em |
| Metric number (small) | Inter Tight | 16px | 600 | — |
| Table cell, control label, button | Inter Tight | 12.5px | 400 (500 for names) | — |
| Sidebar nav item | Inter Tight | 13px | 400 / 500 active | — |
| Descriptive body | Inter | 13px | 400 | — |
| Helper / caption | Inter | 11.5–12px | 400 | — |
| Mono data | JetBrains Mono | 11–11.5px | 400 | — |
| State chip label | JetBrains Mono | 10.5px | 400 | — |
| Column header | JetBrains Mono | 9px | 400 | .13em, uppercase |
| Group label (sidebar) | JetBrains Mono | 9px | 400 | .16em, uppercase |
| Field label | JetBrains Mono | 9.5px | 400 | .13em, uppercase |

### Spacing, radius, geometry

```
Page padding             26px (top/left/right), 60px bottom
Gap between page blocks  16px   (Overview uses 20px)
Gap in a card grid       12px
Card padding             16–18px
Card header              13px 18px, 1px bottom border
Table header row         9px 16px
Table body row           11px 16px  (18px horizontal inside cards)
Column gap in tables     12px (14px on Events)

Radius: card/panel 9px · control/button/chip-group 6px · state chip 4px
        inner tile 7px · progress bar 2px · checkbox 3px · toggle 10px
Border: 1px solid var(--line); inputs var(--line-2); dividers var(--line)

Sidebar width       224px (sticky, full height)
Top bar height      48px (sticky, z-index 5)
Control height      30px (page actions) · 32px (form inputs)
Sidebar nav item    7px 9px padding, 6px radius, 2px active bar
```

No shadows anywhere in the console except overlays/menus (`--shadow`).

### Keyframes

```css
@keyframes vqpulse { 0%,100% { opacity:1 } 50% { opacity:.35 } }
```

Used at `2.4s ease-in-out infinite` for the agent-status dot, `1.6s` for live
state dots and skeleton rows.

---

## Recurring components

Build these first; every screen composes them.

### 1. State chip

```
display:inline-flex; align-items:center; gap:6px;
font-family:JetBrains Mono; font-size:10.5px;
padding:3px 8px (2px 7px inside dense tables);
border-radius:4px;
color:var(--X); background:var(--X-soft); border:1px solid var(--X-line);
+ leading dot: 5px circle, background:var(--X)
```

Mapping (replaces `ui/src/components/StatusChip.tsx`, which currently returns
MUI `Chip` colors):

| Value | X |
| --- | --- |
| Running, Ready, Succeeded | green |
| Migrating, Arriving, Starting, Stopping, Creating, Scheduling(host-side), importing, snapshotting | cyan — **dot pulses** for Migrating / Arriving / importing |
| Maintenance, Pending, Cordoned, Scheduling(unplaced) | amber |
| Failed, NotReady | red |
| Stopped, Disabled, Cancelled | `--text-3` on `--surface-3`, `--line-2` border, `--text-4` dot |

### 2. Data table

A CSS grid, not a data-grid component.

```
Container: background:var(--surface); border:1px solid var(--line);
           border-radius:9px; overflow:hidden

Header row: display:grid; grid-template-columns:<per table>; gap:12px;
            padding:9px 16px; background:var(--surface-2);
            border-bottom:1px solid var(--line);
            font: JetBrains Mono 9px / .13em / uppercase; color:var(--text-3)

Body row:   same grid + gap; padding:11px 16px; align-items:center;
            font-size:12.5px; border-bottom:1px solid var(--line)
            last row: no bottom border
            hover: background:var(--surface-2)
            row-level emphasis: tint whole row with --amber-soft / --cyan-soft /
                                --red-soft when the row is the subject

Footer:     padding:10px 16px; border-top:1px solid var(--line);
            background:var(--surface-2); JetBrains Mono 10.5px var(--text-3);
            "N of M · page X / Y" left, Prev/Next chips right

Cells:      resource names → var(--blue), weight 500, clickable
            machine data → JetBrains Mono 11–11.5px var(--text-2)
            empty       → "—" in var(--text-4)
            row menu    → "···" var(--text-4), justify-self:center
Row select: 12px square, 1px var(--line-3), radius 3px, first column 26px wide
```

Exact `grid-template-columns` per table (copy verbatim):

```
VMs         26px 1.6fr 130px 1fr 70px 100px 120px 1fr 40px
Hosts       1.3fr 110px 130px 1fr 1.3fr 70px 1fr 110px 40px
Networks    1.2fr 110px 1.2fr 1fr 1.4fr 1fr 70px
Volumes     1.6fr 100px 90px 1.3fr 90px 1fr 1fr
Templates   1.4fr 1.2fr 90px 100px 100px 1fr 110px
Tasks       1fr 1.3fr 1.3fr 1.6fr 1fr 1fr
Events      130px 90px 1.3fr 1.2fr 2.6fr        (gap 14px)
SG rules    100px 100px 100px 1fr 1fr 40px
Roles       1.2fr 80px 2fr
Mappings    1.4fr 1fr 90px
```

### 3. Inline progress bar

```
Track: 3px high (4px in the migration banner and image import), radius 2px,
       background:var(--surface-3), overflow hidden, fixed width in tables
       (64px on Overview, 56px on Tasks, 52px on Hosts)
Fill:  background:var(--cyan) for live work, var(--blue) for allocation,
       var(--amber) for a cordoned host
Stacked: multiple spans in one track — e.g. host memory shows
         blue (allocated) + cyan (migrating in) + remaining track (free)
Label: JetBrains Mono 11px in the fill's colour, to the right of the track
```

### 4. Metric card

```
surface card, 16px 18px padding
label      JetBrains Mono 9px .15em uppercase var(--text-3), 11px margin-bottom
value      Inter Tight 25–27px 600 -0.03em, with a 13–14px var(--text-3) unit
progress   3px track, 12px margin-top
caption    Inter 11.5px var(--text-3), 8px margin-top
```

The value takes a semantic colour when the number itself is the alarm (cyan for
migrations in flight, amber for drift), otherwise `--text`.

### 5. Buttons

```
Primary      h30 (h32 in forms), padding 0 13px, radius 6px,
             background:var(--blue), #FFF, 12.5px, weight 500
Secondary    h30, padding 0 12px, 1px var(--line-2), background:var(--btn),
             color:var(--text-2); hover background:var(--btn-hover)
Destructive  1px var(--red-line), background:var(--red-soft), color:var(--red)
Caution      1px var(--amber-line), background:var(--amber-soft),
             color:var(--amber)   ← used for Drain
Disabled     1px var(--line), background:var(--surface-2), color:var(--text-4)
```

### 6. Form controls

```
Input        h32, 1px var(--line-2), radius 6px, background:var(--inset),
             padding 0 11px, JetBrains Mono 12.5px
  focus      border var(--blue) + box-shadow 0 0 0 3px var(--blue-soft)
  invalid    border var(--red), text var(--red), helper text var(--red) Inter 11.5px
  overridden border var(--amber-line) + JetBrains Mono 10.5px var(--amber)
             helper reading "template: <value>"
  inherited  text var(--text-3), helper "inherited" in var(--text-4)
Label        JetBrains Mono 9.5px .13em uppercase var(--text-3), 6px gap
Helper       Inter 11.5px var(--text-4)
Select       same as input + "▾" 10px var(--text-4) right-aligned
Segmented    1px var(--line-2), radius 6px, h32, equal flex segments,
             1px left border between; active segment background var(--blue-soft)
             + color var(--blue) + weight 500
Toggle       34×19 pill, radius 10, 15px white knob, 2px inset padding
             on: background var(--blue), knob right
             off: background var(--surface-3), 1px var(--line-2), knob var(--text-4), left
Checkbox     13px, radius 3px; checked var(--blue) + white 9px ✓;
             unchecked 1px var(--line-3)
Radio        13px circle; selected 4px var(--blue) border; else 1px var(--line-3)
```

### 7. Filter bar (list screens)

```
Search field  h30, max-width 300px, 1px var(--line-2), radius 6px,
              background var(--surface); placeholder var(--text-3) 12.5px
Segmented count filters  one bordered group, h30, per-segment padding 0 11px,
              active = var(--blue-soft)/var(--blue)/500; live counts in the label
              ("All 128", "Running 126", "Migrating 3" — the migrating segment's
              label is var(--cyan) even when inactive)
Right side    "Columns" and "Export" secondary buttons, margin-left auto
```

---

## App shell

### Sidebar — 224px, `background:var(--surface-2)`, 1px right border, sticky, 100vh

- **Brand block**, h48, 1px bottom border, padding 0 16px: 22px vQuasar mark in
  `--blue` + wordmark. Wordmark = `v` at 12.5px weight 400 opacity .65 followed
  by `Quasar` at 14.5px weight 600, tracking -0.012em, **no space between them**.
- **Four nav groups**, 16px apart, group label JetBrains Mono 9px .16em uppercase
  `--text-4` with 7px bottom padding:

```
FLEET               Overview                          —
                    Hosts                            24
COMPUTE             Virtual machines                128
                    Images                            9
                    Templates                         6
NETWORK & STORAGE   Networks                          7
                    Security groups                  12
                    Volumes                         214
OPERATIONS          Tasks                             4
                    Events                            —
                    Access control                    —
                    Settings                          —
```

  Item: `display:flex; gap:9px; padding:7px 9px; radius:6px; font-size:13px`,
  a 2px × 13px leading bar, label `flex:1`, trailing count in JetBrains Mono
  10px `--text-4`. Active: `background:var(--blue-soft)`, `color:var(--blue)`,
  weight 500, bar `var(--blue)`. Inactive: transparent bar, `--text-2`.
  Detail routes keep their parent active (`/vms/:id` → Virtual machines).
  Counts come from the existing list queries.

- **Footer**, 1px top border, padding 11px 14px: cyan 6px dot with `vqpulse 2.4s`
  + "24 / 24 agents connected" (JetBrains Mono 10px `--cyan`), then
  "control v0.9.2 · reconciled 3s ago" in `--text-4`. Hide behind
  `can("host:read")`.

The MVP's `Access control` visibility rule stays: only render it when
`can("iam:read")`.

### Top bar — h48, `background:var(--surface)`, 1px bottom border, sticky, padding 0 18px

Left: breadcrumb, JetBrains Mono 12.5px — cluster name in `--text-3`, `/` in
`--text-4`, current screen in `--text`.

Right, 10px gaps:
- Command palette trigger: h28, min-width 220px, 1px `--line-2`, radius 6px,
  `background:var(--surface-2)`, "⌘K" in mono 11px + "Search or run a command"
  12px `--text-3`. **Not yet designed as an open panel** — wire the affordance,
  defer the palette.
- Theme switch: bordered 2-segment group, h28, labels "DARK"/"LIGHT" in
  JetBrains Mono 10px .06em; active segment `--blue-soft`/`--blue`, inactive
  `--text-3`. Persist to `localStorage`, honour `prefers-color-scheme` on first
  load.
- User: 12px left padding, 1px left border, 22px avatar square (radius 5px,
  `--blue-soft` bg, `--blue-line` border, `--blue` mono 10px initials) +
  username 12.5px `--text-2`. Click → menu with Sign out (from
  `ui/src/auth/AuthProvider.tsx`).

### Content

`flex:1`, padding `26px 26px 60px`, `display:flex; flex-direction:column`,
16px gap (20px on Overview). Page header is a flex row, `align-items:flex-end`,
`justify-content:space-between`: left = 21px/600 title + Inter 13px `--text-3`
subtitle stating counts and current condition; right = action buttons, 8px gap.

---

## Screens

### Route map

| Route | Screen | Source hooks |
| --- | --- | --- |
| `/` | Overview | `useHosts` `useVms` `useTasks` `useEvents` `useNetworks` |
| `/hosts` | Hosts | `useHosts`, `useSetHostSchedulable`, `useDrainHost`, `useEnrollHost`, `useRegisterHost` |
| `/hosts/:id` | Host detail — **new route** | `useHosts` + host VMs, `cpu_features` |
| `/vms` | Virtual machines | `useVms`, `useVmAction`, `useHosts` |
| `/vms/:id` | VM detail | `useVm`, `useVmMetrics`, `useTasks` |
| `/vms/:id/console` | Console — **not redesigned** | existing |
| `/vms/new` | Create VM | existing form, restyled per §Templates |
| `/images` | Images | `useImages` |
| `/templates` | Templates + create-from-template | `useTemplates`, `useCreateVmFromTemplate` |
| `/volumes` | Volumes | `useVolumes`, `useVolumeSnapshots` |
| `/networks` | Networks (+ IPAM, SG summary) | `useNetworks`, `useIpAllocations` |
| `/security-groups` | Security groups | `useSecurityGroups` |
| `/tasks` | Tasks | `useTasks` |
| `/events` | Events | `useEvents` |
| `/iam` | Access control | `ui/src/api/iam.ts` |
| `/settings` | Settings — **new route** | control config (read-only) |

### 1. Overview (`/`)

Title "Overview", subtitle "Desired and observed state across N hosts. Last full
reconcile Xs ago." Actions: "Reconcile now" (secondary), "Create VM" (primary).

**Five metric cards**, `grid-template-columns:repeat(5,1fr)`, 12px gap:

| Card | Value | Bar | Caption |
| --- | --- | --- | --- |
| Hosts ready | `23 / 24` | green fill + amber remainder | "host-07 cordoned" |
| VMs running | `126 / 128` | blue fill + `--text-4` remainder | "2 stopped · 0 failed" |
| Live migrations | `3` cyan, unit "in flight" | cyan | "4.1 GiB/s aggregate" cyan |
| Capacity used | `61` unit "% memory" | blue | "2.9 TiB / 4.8 TiB · 47% vCPU" |
| Drift | `1` amber, unit "resource" | amber | "vm-build-27 awaiting apply" |

**Row two**, `grid-template-columns:1.5fr 1fr`:

- **Active tasks** card. Header "Active tasks" + right-aligned mono 10.5px
  "persisted state machines". Table `1.5fr 1fr 1fr 1.5fr`, columns
  Task / Resource / Placement / State. Task type in mono `--text-2`, resource in
  `--blue`, placement in mono 11.5px `--text-3` (`host-02 → host-09`, or
  "unscheduled"). State cell = inline progress + mono 11px label, or a state chip
  when there is no progress (`Pending capacity` in amber).
- **Events** card. Header "Events" + "View all" link (`--blue`, mono 10.5px).
  Five rows, each `display:flex; gap:11px; padding:11px 18px`: a 5px severity dot
  (`margin-top:6px`) then message 12.5px `--text` + mono 10px `--text-4`
  "18:24:02 · vm.migration.started". Dot colour: cyan info-live, green success,
  amber warning, red error, `--text-4` neutral.

**Host capacity** card, full width. Header + inline legend (8px 2px-radius
swatches: allocated blue / migrating-in cyan / free `--surface-3`, mono 10px).
Body `grid-template-columns:repeat(8,1fr)`, 10px gap, one column per host:
mono 10.5px `host-01` + right-aligned percentage `--text-4`, then a 24px-tall
4px-radius `--surface-3` track filled bottom-up
(`display:flex; flex-direction:column-reverse`). A cordoned host's track gets a
`1px dashed var(--amber-line)` border and an amber fill at .7 opacity; a host
receiving a migration stacks a cyan segment above its blue segment. Show the
8 most-loaded hosts; the card is a hover target for a fuller view (not designed).

### 2. Hosts (`/hosts`)

Subtitle "23 Ready · 1 cordoned · all agents on cloud-hypervisor 41.0".
Actions: "Register manually" (secondary), "Enroll host" (primary).

Columns: Host / State / Scheduling / CPU model / Memory used / VMs /
Agent endpoint / Heartbeat / menu.

- Scheduling is mono 11px text, not a chip: `Schedulable` `--text-2`,
  `Cordoned` `--amber`, `Receiving` `--cyan`, `Unschedulable` `--text-4`.
- Memory used = 52px stacked progress + mono 11px `144 / 200 GiB`.
- Heartbeat in mono 11px `--text-3`; `--red` when older than the NotReady
  threshold.
- A cordoned host's whole row is tinted `--amber-soft`.
- Row menu: Cordon / Uncordon, Drain (evacuate VMs), Register…, matching the
  MVP's permission gate `can("host:manage")`.

Keep the MVP's three dialogs (Register, Enroll, Drain result) and restyle them:
card surface, 9px radius, `--shadow`, mono 12px for the generated
`install.sh` bootstrap command in a `--inset` block, and the "token shown once"
warning as an amber banner.

### 3. Host detail (`/hosts/:id`) — new

Back link "← Hosts" (mono 10.5px `--blue`). Title = host name + a Ready chip +,
when applicable, a pulsing cyan "Receiving migration" chip. Sub-line, mono 11px
`--text-3`: `10.0.0.19:9500 · mTLS · agent v0.9.2 · cloud-hypervisor 41.0 ·
linux 6.8.0-41`. Actions: Cordon (secondary), Drain (caution/amber).

Four metric cards: Memory (`110 / 200 GiB`, stacked blue+cyan), vCPU allocated
(`38 / 64 logical`), VMs (`5` + unit "+1 arriving", caption "4 running ·
1 stopped"), Heartbeat (`1s` green + "generation 31 reconciled").

Then `1fr 1fr`:

- **Placed VMs** table (`1.5fr 100px 1fr 1fr`) — VM / State / vCPU+mem / IP.
  State as bare mono 10.5px in its semantic colour here, not a chip (density).
  An arriving VM's row is tinted `--cyan-soft` with state "Arriving" and IP
  "pending".
- **Migration compatibility** card — `130px 1fr` label/value rows: CPU vendor,
  Guest ISA flags (wrapping mono 10px pills, 1px `--line-2`, radius 4px),
  Compatible targets (green), Blocked targets (amber, with the reason:
  "9 hosts — missing vaes"). Closing note in Inter 12px `--text-3` above a
  `--line` divider explaining the superset rule. Data: `Host.cpu_vendor`,
  `Host.cpu_features`.

### 4. Virtual machines (`/vms`)

Subtitle "128 VMs across 24 hosts · 3 migrating". Actions: "From template"
(secondary), "Create VM" (primary). Full filter bar (see §7).

Columns: select / Name / State / Host / vCPU / Memory / IP / Image / menu.

- Name → `/vms/:id`, `--blue` weight 500.
- A migrating VM's Host cell reads `host-02 → host-09`.
- Unset values are "—" in `--text-4`.
- Menu: Start / Stop / Restart / Migrate… / Snapshot / Delete, gated by
  `can("vm:power")` and `can("vm:delete")`.
- Footer pagination "7 of 128 · page 1 / 6".

### 5. VM detail (`/vms/:id`)

Back link, title = VM name + state chip. Sub-line mono 11px:
`<uuid> · generation 14 · observed 14`. Actions: Console, Snapshot, Stop
(secondary ×3), Delete (destructive).

**Tab bar**: `display:flex; gap:2px; border-bottom:1px solid var(--line)`, each
tab `padding:9px 14px; font-size:12.5px`; active `--blue` + 2px `--blue` bottom
border with `margin-bottom:-1px`; inactive `--text-3`. Tabs: Overview, Spec,
Networking, Storage, Console, Tasks, Events.

**Migration banner** (only while migrating): `background:var(--cyan-soft)`,
1px `--cyan-line`, radius 9px, padding 16px 18px, flex with the actions right.
Title "Live migration in progress" 13.5px 600 `--cyan` + mono 10.5px
"task tsk_8f21c · state Transferring". A 4px cyan progress bar, then a mono 11px
`--text-2` row with 22px gaps: `host-02 → host-09`, `62% · 9.9 GiB / 16 GiB`,
`1.4 GiB/s`, `downtime est. 180 ms`. Actions: "Pause" (h28, cyan-line border,
cyan text) and "Cancel" (secondary).

**Three metric cards** (`1fr 1fr 1fr`):
- CPU — `34` "% of 8 vCPU" + a 34px-tall 12-bar sparkline; each bar
  `background:var(--blue-soft); border-top:2px solid var(--blue)`, 2px gaps.
- Memory — `11.2` "GiB / 16 GiB" + an 8px rounded blue bar.
- Throughput — two figures side by side (16px/600 value + mono 10px caption
  "disk write" / "net tx") over a 12-bar cyan sparkline where older bars are
  `opacity:.5`.

Data: `useVmMetrics` (`cpu_pct`, `mem_bytes`, `disk_*`, `net_*`).

**Bottom row** (`1fr 1fr`):
- **Specification** card — `150px 1fr` rows, label `--text-3` 12.5px, value mono
  11.5px: Machine type, Boot, vCPU (`8 boot / 16 max`), Memory
  (`16 GiB / 64 GiB max`), Placement, Cloud-init, Desired power (green when
  Running). Straight from `VirtualMachineSpec`.
- **Interfaces** table (`1fr 1fr 1fr 1fr`): Network (blue) / Address / MAC (mono
  11px `--text-3`) / Groups. Below it, **Volumes** table
  (`1.4fr 1fr 1fr 1fr`): Volume / Size / Format / Serial.

### 6. Images (`/images`)

Subtitle "9 images · 1 importing · managed images are reference-counted".
Action: "Import image".

**Card grid** `repeat(3,1fr)`, 12px gap. Each card: name 14px/600, mono 10.5px
`--text-3` descriptor (`qcow2 · firmware boot · cloud-init`), a status chip
top-right, then mono 11px label/value rows (size, default disk, derived
volumes). An importing image gets a `--cyan-line` border, a pulsing cyan chip,
`transferred 4.1 / 5.6 GiB` in cyan, a 4px cyan progress bar and the source URL.
A failed import uses the red equivalents and shows `Image.error`.

Below, a **Templates** table (`1.4fr 1.2fr 90px 100px 100px 1fr 110px`):
Template / Image / vCPU (`4 / 8`) / Memory / Disk / Network / Machine — machine
type `microvm` in `--cyan`, `standard` in `--text-3`.

### 7. Templates → Create VM (`/templates`, `/vms/new`)

The canonical **form** design. `max-width:1080px`.

Breadcrumb "Templates / tpl-api-standard" (mono 10.5px `--blue`), title
"Create VM from template", subtitle explaining overrides are recorded in the
VM's spec.

- **Identity** card — 2-column grid, 16px gap: Name (focused-state input with a
  1px `--blue` caret, helper "Lowercase, hyphenated. Used as the cloud-init
  hostname.") and Template (select; helper shows the resolved
  `image · network · machine type`).
- **Overrides** card — header carries a right-aligned mono 10.5px `--amber`
  count "2 fields differ from template". `repeat(3,1fr)` grid: Boot vCPU,
  Memory (MiB), Disk size, Network, Placement (segmented Auto / Pin host),
  Power on after create (toggle + "Yes — desired state Running"). Every field
  renders in one of three states — **overridden** (amber border + "template: 4"),
  **inherited** (`--text-3` value + "inherited"), or **default**.
- **Submit bar** — `background:var(--surface-2)`, 1px `--line`, radius 9px,
  padding 16px 18px, flex. Left: the exact request that will be sent, mono 11px
  `--text-3`, `line-height:1.7` — `POST /api/v1/vms:from-template` then the JSON
  body containing only the overridden keys. Right: Cancel (secondary) +
  "Create VM" (primary, h32).

Showing the request body is deliberate: it teaches the API and makes the
override semantics unambiguous. Keep it.

### 8. Volumes (`/volumes`)

Subtitle "214 volumes · 38.4 TiB provisioned · 61 snapshots". Actions:
"Snapshots" (secondary), "Create volume" (primary).

Columns: Volume / Size / Format / Attached to / Serial / Source image /
Snapshots. Unattached → "unattached" in `--text-4`; a volume mid-snapshot shows
"14 · snapshotting" in `--cyan`; a bootable volume shows its
`source_image_id` name (others "—").

### 9. Networks (`/networks`)

Subtitle "4 VLAN-backed · 3 VXLAN overlays · IPAM managed where a CIDR is set".
Action: "Create network".

Table columns: Network / Isolation / CIDR v4 / Gateway / Pool / DNS / NICs.
Isolation is mono 10.5px: `vlan 120` in `--text-2`, `vni 10307` in `--cyan`
(overlays are the moving/spanning thing). A DHCP-only family shows "DHCP" and
"—" in `--text-4`.

Second row (`1fr 1fr`):
- **Security group summary** — header "Security group · sg-web" + mono 10.5px
  "attached to 41 NICs"; rules table `90px 90px 1fr 1fr` with `ingress` green
  and `egress` blue.
- **IP allocations** — mono 11px "pool utilisation" / "64 / 496 addresses", an
  8px blue bar, then a `repeat(16,1fr)` grid of 12px 2px-radius cells (blue
  allocated, cyan reserved-for-migration, `--surface-3` free) and a mono 10px
  legend. Data: `IpAllocation` + `pool_v4_start/end`.

### 10. Security groups (`/security-groups`)

Master/detail: `grid-template-columns:280px 1fr`.

- **Left** list card: `--surface-2` header "Groups" (mono 9px .13em uppercase),
  8px padding body, each item `padding:8px 10px; radius:6px` with a right-aligned
  rule count; selected item `--blue-soft`/`--blue`/500.
- **Right** detail card: header = group name 13.5px/600 + Inter 12px `--text-3`
  description, "Add rule" secondary button right. Rules table
  `100px 100px 100px 1fr 1fr 40px` — Direction / Ethertype / Protocol /
  Port range (`443 – 443`, "—" for any) / Remote CIDR / menu.

### 11. Tasks (`/tasks`)

Subtitle "Every mutating operation is a persisted task. Failed tasks retain
their last state and error."

Columns: Task ID (mono `--blue`) / Type / Resource / State / Started / Duration.
Running tasks show a 56px progress + mono state label; terminal tasks show a
state chip.

**A failed task is followed by its own error row** — a full-width row,
`background:var(--red-soft)`, mono 11px `--red`, `line-height:1.6`, prefixed
with the task id and agent:
`tsk_8f0c2 · agent host-05: cloud-hypervisor exited with code 1 — "…"`.
This replaces the MVP's dismissible alert; the error must not be dismissible or
detached from its row.

### 12. Events (`/events`)

Subtitle "Append-only audit stream · retained 90 days". Right side: a segmented
severity filter (All / Info / Warning / Error).

Columns `130px 90px 1.3fr 1.2fr 2.6fr` with a 14px gap: Timestamp (mono 11.5px
`--text-3`, millisecond precision `18:24:02.114`), Severity (bare mono word —
`info` cyan, `warning` amber, `error` red), Event type (mono `--text-2`),
Resource (`--blue`), Message. Error rows are tinted `--red-soft` and their
message text is `--red`.

The whole table is monospace — it is a log, and column alignment matters more
than warmth.

### 13. Access control (`/iam`)

Subtitle "OIDC issuer keycloak.internal · roles mapped from groups · 4 built-in
roles". Action: "Create role".

`grid-template-columns:1.1fr 1fr`:
- **Roles** (`1.2fr 80px 2fr`) — Role (blue 500) / Type (`builtin` `--text-3`,
  `custom` `--blue`) / Permissions as wrapping mono 10px pills (1px `--line-2`,
  radius 4px). `admin` shows a single `*`.
- **Group → role mappings** (`1.4fr 1fr 90px`) — OIDC group / Role / Users.

Gate the whole route on `can("iam:read")`.

### 14. Settings (`/settings`) — new

`max-width:900px`. Subtitle "Control-plane configuration. Values sourced from
control.toml are read-only here."

- **Control plane** card — `200px 1fr` read-only rows: API listen, Database,
  Agent mTLS CA (with expiry), Reconcile interval.
- **Migration policy** card — 18px padding, 16px gaps, `--line` divider above
  each row after the first. Each row: label 12.5px + Inter 11.5px `--text-3`
  explanation on the left, control right. Rows: "Allow cross-CPU-model
  migration" (toggle on), "Auto-evacuate on NotReady" (toggle off), "Max
  concurrent migrations" (80px numeric input, value 4).

---

## Interactions & behavior

- **Navigation** — sidebar items and every `--blue` resource name are links.
  Detail screens carry a "← <parent>" back link; the parent nav item stays active.
- **Theme** — instant token swap, no transition. Persist; respect
  `prefers-color-scheme` on first visit only.
- **Hover** — table rows → `--surface-2`; secondary buttons → `--btn-hover`;
  nav items → `--surface-3` when inactive. No transforms, no scale, no lift.
- **Live data** — `vqpulse` is the only animation, and only on genuinely live
  things. Progress bars update in place; never animate a bar's width with a
  transition longer than 200ms or it lies about throughput.
- **Loading** — skeleton rows: 11px tall, 3px radius, `--surface-3`, staggered
  widths (70 / 100 / 88 / 54%), `vqpulse 1.6s`. Never a spinner in a table; the
  MVP's full-page `CircularProgress` should also go (skeleton the shell).
- **Empty** — 1px dashed `--line-2`, radius 7px, 26px padding, centered: a 34px
  outline vQuasar mark in `--line-3`, a 12.5px/500 line ("No volumes yet"), and
  an Inter 11.5px `--text-3` sentence naming the action that fixes it.
- **Errors** — `--red-soft` panel, 1px `--red-line`, radius 7px, padding 13px
  15px: 12.5px/500 `--red` summary line ("Start failed on host-05") over the raw
  agent message in mono 10.5px `--text-2`. Always show the raw message; operators
  need it.
- **Validation** — name fields reject underscores and uppercase; show the
  invalid input state plus "Underscores are not permitted." Validate on blur,
  clear on input.
- **Destructive actions** — Delete opens a confirm dialog that requires typing
  the resource name. Drain shows the existing drain-result dialog (migrating vs.
  skipped, skipped reasons in an amber block).
- **Responsive** — desktop-first, min 1280px. Below ~1100px collapse the sidebar
  to icons-only (blocked on the icon family) and drop the 5-up metric grid to
  3-up then 2-up. Tables scroll horizontally rather than reflow.

## State

Per-screen local state only; server state stays in TanStack Query.

```
theme: 'dark' | 'light'            persisted, global
sidebarCollapsed: boolean          persisted (once icons exist)
<list>.filter: { q, state }        per list screen, URL query params
<list>.selection: Set<id>          bulk actions
vmDetail.tab: enum                 URL segment or query param
sg.selectedGroupId: string         master/detail
createVm.overrides: Partial<...>   diffed against the template to drive the
                                   overridden/inherited field states
dialogs: { register, enroll, drainResult, confirmDelete }
```

Polling: keep the MVP's query intervals, but hosts/VMs/tasks need ≤2s while any
task is Running so progress bars and the agent-status dot stay honest.

## Assets

- **The vQuasar mark** is inline SVG, 64×64 viewBox, `currentColor`, no
  gradients. Copy it verbatim from either bundled file (search `viewBox="0 0 64
  64"`). Three parts: an accretion-plane arc (rotated -14°, open on the right,
  with a short tail), two tapered jet polygons, and a core circle with a
  knockout dot whose fill must match the surface behind it.
  - Header/sidebar 22–23px, `stroke-width:4.4` on the arc.
  - At ≤32px drop the tail; at 16px thicken the arc to 6 and merge the jets into
    the core.
  - Jets may be `--cyan` on a large mark; use a single colour at small sizes.
  - Watermark variant: outline only, 1.6–2px, `--line`/`--surface-3`.
- **Wordmark** is live text (Inter Tight), never an image. Lowercase `v` smaller
  and lighter, joined to `Quasar`.
- No other imagery. Replace the MVP's `@mui/icons-material` imports; do not
  substitute another icon set without the design pass noted above.
- `vQuasar Brand Guidelines.dc.html` in this bundle is the identity reference —
  logo construction, small-size behaviour, colour parity tests, diagram
  language, and the voice rules for any copy you write.

## Files

| File | What it is |
| --- | --- |
| `vQuasar Console.dc.html` | The console design — all 14 screens, both themes. Open in a browser; switch screens in the sidebar and themes in the top bar. |
| `vQuasar Brand Guidelines.dc.html` | Brand identity reference — mark, wordmark, palette, type, diagram language, voice. |

Both are prototypes in the design tool's format. Read them for values; build in
`ui/`.

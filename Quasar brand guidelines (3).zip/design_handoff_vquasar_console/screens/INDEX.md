# Screens

Captured at 1440px wide from `vQuasar Console.dc.html`. Long screens are cut at
the fold — open the HTML for the full page.

## Dark (default)

| File | Screen | Route |
| --- | --- | --- |
| 01-overview-dark.png | Overview | `/` |
| 02-hosts-dark.png | Hosts | `/hosts` |
| 03-host-detail-dark.png | Host detail | `/hosts/:id` (new) |
| 04-virtual-machines-dark.png | Virtual machines | `/vms` |
| 05-vm-detail-dark.png | VM detail, mid-migration | `/vms/:id` |
| 06-images-dark.png | Images + Templates table | `/images` |
| 07-create-vm-from-template-dark.png | Create VM from template (form patterns) | `/templates`, `/vms/new` |
| 08-networks-dark.png | Networks + IPAM + SG summary | `/networks` |
| 09-security-groups-dark.png | Security groups (master/detail) | `/security-groups` |
| 10-volumes-dark.png | Volumes | `/volumes` |
| 11-tasks-dark.png | Tasks, incl. inline failure row | `/tasks` |
| 12-events-dark.png | Events | `/events` |
| 13-access-control-dark.png | Access control | `/iam` |
| 14-settings-dark.png | Settings | `/settings` (new) |
| 15-design-system-dark.png | Design system — tokens, chips, controls, states | — |

## Light

| File | Screen |
| --- | --- |
| 16-overview-light.png | Overview |
| 17-hosts-light.png | Hosts |
| 18-virtual-machines-light.png | Virtual machines |
| 19-tasks-light.png | Tasks |
| 20-design-system-light.png | Design system |

Both themes resolve from one token set (`brand_assets/tokens/vquasar-tokens.css`).
The Design system pair is the fastest way to check parity.

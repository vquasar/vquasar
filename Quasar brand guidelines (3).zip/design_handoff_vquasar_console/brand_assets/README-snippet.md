<p align="center">
  <img src="docs/brand/vquasar-logo-horizontal-light-bg.svg#gh-light-mode-only" alt="vQuasar" width="300">
  <img src="docs/brand/vquasar-logo-horizontal-dark-bg.svg#gh-dark-mode-only" alt="vQuasar" width="300">
</p>

<p align="center"><strong>Cloud Hypervisor, orchestrated.</strong></p>

<p align="center">
vQuasar is an open-source virtualization control plane built directly around
Cloud Hypervisor. It manages hosts, virtual machines, networking, storage,
migration and operational state without requiring libvirt or Kubernetes.
</p>

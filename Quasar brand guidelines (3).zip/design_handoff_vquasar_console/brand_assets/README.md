# vQuasar brand assets

Production files for the vQuasar identity: logo variants, favicons, social card,
and the design tokens both themes are built from.

**Tagline:** Cloud Hypervisor, orchestrated.
**Campaign line (selective use):** Virtualization without legacy layers.

---

## Contents

### `logo/`

| File | Use |
| --- | --- |
| `vquasar-mark.svg` | **Primary icon.** Blue plane and core, Ion Cyan jets. Default on dark surfaces. |
| `vquasar-mark-blue.svg` | Single-colour Quasar Blue. Use when cyan would compete. |
| `vquasar-mark-mono.svg` | `currentColor` — inherits text colour. Use in code, docs, buttons. |
| `vquasar-mark-white.svg` | Solid Signal White, for photography and dark brand surfaces. |
| `vquasar-mark-black.svg` | Solid Deep Space, for light backgrounds and one-colour print. |
| `vquasar-mark-watermark.svg` | 1.6px outline only. Behind diagrams and title slides. |
| `vquasar-mark-32.svg` | 32px build — tail shortened. |
| `vquasar-mark-24.svg` | 24px build — no tail, thicker plane, wider jets. |
| `vquasar-mark-16.svg` | 16px build — jets merged into the core silhouette. |
| `vquasar-logo-horizontal-dark-bg.svg` | Primary lockup, light text. |
| `vquasar-logo-horizontal-light-bg.svg` | Primary lockup, dark text. |
| `vquasar-logo-horizontal-tagline.svg` | Lockup with the tagline set beneath the wordmark. |
| `vquasar-logo-compact.svg` | 22px mark + 16px wordmark. The application header lockup. |
| `vquasar-app-icon.svg` / `-512.png` | App and avatar icon: 512 square, 114 radius, dark radial container. |
| `vquasar-mark-512.png` / `-white-512.png` | Raster fallbacks where SVG is not accepted. |

### `favicon/`

`favicon.svg` (rounded dark tile), `favicon-16.png`, `favicon-32.png`,
`apple-touch-icon-180.png`, and `head-snippet.html` — paste-ready `<link>` and
`<meta>` tags including per-scheme `theme-color`.

### `social/`

`og-card.svg` / `og-card.png` — 1200×630 Open Graph / Twitter card.

### `tokens/`

`vquasar-tokens.css` — the complete custom-property set for both themes plus the
`vq-pulse` keyframe. Import this once, set `data-theme` on `<html>`, and no
component needs a hex value.

`vquasar-tokens.json` — the same values as data, plus semantic colour rules,
type rules, radius, layout and motion constants. Feed it to a token pipeline or
read it as documentation.

### `README-snippet.md`

Paste-ready repository header using the light/dark GitHub anchor trick
(`#gh-light-mode-only` / `#gh-dark-mode-only`). Copy the two lockups into
`docs/brand/` in the repo first.

---

## The mark

Three elements, always in this relationship:

1. **Core** — a solid circle with a punched-out centre. The control plane and its
   authoritative state.
2. **Accretion plane** — an elliptical arc rotated −14°, open on the right with a
   short tail. The managed resource plane; the opening and tail form the `Q`.
3. **Opposing jets** — two tapered polygons leaving the core. Their negative
   space reads as a `v`, and as migration across the system.

The centre of the core is a **transparent hole**, punched with an SVG mask — it
is not a white dot. The mark therefore sits on any background without editing.

### Size builds

Do not scale the primary mark below 32px. Swap to the purpose-built file:

| Target | File | What changes |
| --- | --- | --- |
| ≥ 40px | `vquasar-mark.svg` | full geometry, tail, cyan jets |
| 32px | `vquasar-mark-32.svg` | shortened tail, plane stroke 4.4 |
| 24px | `vquasar-mark-24.svg` | no tail, stroke 5, wider jet bases |
| 16px | `vquasar-mark-16.svg` | stroke 6, jets merged into an enlarged core |

The application header uses **22–24px** in the dense toolbar.

### Clear space

Minimum clear space on all sides equals the **core diameter** (15/64 of the mark
box — 23% of the mark's height). In the horizontal lockup, the gap between mark
and wordmark is 36% of the mark height; do not adjust it.

### Don't

- Don't put a gradient inside the mark. Gradients are permitted on the container
  behind it (see the app icon) and in hero art — never on the geometry.
- Don't rotate, mirror, skew or re-space the three elements.
- Don't fill the core's centre hole.
- Don't outline the primary mark; the outline build is the watermark, at 1.6px,
  in a line colour — not as a logo.
- Don't set the mark on a mid-tone that leaves the plane under 3:1 contrast.
- Don't pair the mark with any wordmark other than `vQuasar`.

---

## Wordmark

`vQuasar` — one word, always. The lowercase `v` is smaller and lighter (about
74% of the cap size, weight 400, opacity 0.65) but **joined**: never `v Quasar`,
never a floating version marker, never all-lowercase `vquasar` as a public name.

All-lowercase `vquasar` is correct for repositories, binaries, package names,
service identifiers and URLs: `vquasar-control`, `vquasar-agent`,
`vquasar-client`.

**The lockup SVGs use live `<text>` with `font-family="Inter Tight"`.** They
render correctly where the font is available (web, with the font loaded) and fall
back to Helvetica elsewhere. Before shipping these to print, PDF, or any context
you do not control, **outline the text** — and take the customisation pass the
brand direction calls for: open the `Q` tail to the jet angle, sharpen the inner
join of the `v`, widen tracking slightly. That pass has not been done; the
current lockups are untouched font output.

---

## Colour

### Brand palette

| Name | Hex | Use |
| --- | --- | --- |
| Quasar Blue | `#4F9CF9` | Primary actions, selection, principal logo accent |
| Ion Cyan | `#58D6F5` | **Live states only** — migration, connectivity, streaming |
| Deep Space | `#0B0F16` | Primary dark background |
| Control Surface | `#161B22` | Cards, navigation, raised surfaces |
| Signal White | `#F4F7FB` | Primary text, light-background logo use |
| Core Amber | `#F5A94A` | Optional. Warnings, transitions, the core itself |

Amber never becomes a second primary. The brand stays predominantly blue,
charcoal and white.

### The cyan rule

Ion Cyan means *something is moving right now*: an active migration, a connected
agent, a streaming console, a running import, a task in progress. A pulsing cyan
dot is a promise that bytes are in flight. Never use cyan decoratively — it is
the most load-bearing colour in the system.

### Light theme

Light-theme accents are darkened for AA contrast on white (`--vq-blue` becomes
`#1E6FD9`, cyan `#0A7E9E`, amber `#A66200`). **Never reuse the dark hexes on a
light surface.** Both themes are equal in status; light is not a fallback.

### Gradients

A blue→cyan gradient (`#4F9CF9 → #58D6F5`) is permitted in website hero art,
release graphics and motion. The canonical logo must remain valid as a flat
one-colour mark, and gradients are never mandatory.

---

## Typography

```
Inter Tight  400 500 600 700   brand, UI, headings, table cells, buttons
Inter        400 500 600       descriptive body copy and helper text
JetBrains Mono 400 500         identifiers, addresses, sizes, timestamps,
                               state names, column headers
```

The rule that keeps everything coherent: **anything machine-generated is
monospace.** Anything human-written is Inter Tight, or Inter when it is a
sentence of explanation.

Avoid rounded science-fiction typefaces, stencil lettering and techno display
fonts. The "quasar" idea lives in the name and the mark, not the type.

---

## Voice

Precise and technical. The astronomy metaphor belongs in the name and the mark,
not in every sentence.

> **Yes:** vQuasar manages Cloud Hypervisor fleets through a reconciled control
> plane and per-host agents.
>
> **Yes:** Live migration is implemented as a persisted state machine.
>
> **No:** Harness the limitless energy of a quasar to revolutionise your cloud
> journey.
>
> **No:** Seamlessly teleport workloads across the infrastructure galaxy.

---

## Not in this package

Two things are deliberately missing and need a design pass before they ship:

1. **The functional icon family** — hosts, VMs, networks, volumes, images,
   migration, security groups, tasks, events. These should be consistent-weight
   line icons optimised for clarity; the quasar motif must **not** be forced into
   them. The logo owns the brand; interface icons own legibility. Until they
   exist, the console's navigation is text-only — do not substitute a generic
   icon set.
2. **Outlined, customised wordmark paths** (see Wordmark above).

## Related

`vQuasar Brand Guidelines.dc.html` (in the design handoff bundle) is the visual
reference for all of the above — logo construction, small-size behaviour, colour
parity tests, diagram language, and the full messaging pillars.
